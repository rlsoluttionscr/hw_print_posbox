.. _changelog:

Changelog
=========



`Version 1.1(Tue, 10 Nov 2020 11:16:45 +0300)
-----------------------------------------------
- [IMP] Rearranged character set tables so that EURO PC858 comes before others. This is in light of cases where printers in euro zone are forced by python to select Vietnamese characters over euro characters

`Version 1.0 (Wed Nov  6 03:27:58 2019)`
-----------------------------------------
- Initial Release for Odoo 12

