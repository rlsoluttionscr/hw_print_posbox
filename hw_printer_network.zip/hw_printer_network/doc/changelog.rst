`2.0.1`
-------

- **FIX:** Orders sent to print are not missed after the connection to Network Printer is lost.

`2.0.0`
-------

- **IMP:** Asynchroneous checking of network status to speed it up when there are more than one network printer in the system. Also, there is no need to modify code of posbox anymore.

`1.0.0`
-------

- Init version
