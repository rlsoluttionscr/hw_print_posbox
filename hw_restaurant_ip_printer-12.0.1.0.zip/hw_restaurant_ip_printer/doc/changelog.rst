.. _changelog:

Changelog
=========


`Version 1.0 (Thu Nov 14 08:24:28 2019)`
-----------------------------------------
- Initial Release for Odoo 12.0

